# Snapshot_Spectral_Image_demosaicing
Graph and Rank Regularized Matrix Recovery for Snapshot Spectral Image Demosaicing


The execution of the code steps is found in the main.m file

The desciption of the process is presented in
G. Tsagkatakis, M. Bloemen, B. Geelen, M. Jayapala, and P. Tsakalides, "Graph and Rank Regularized Matrix Recovery for Snapshot Spectral Image Demosaicing", submitted to IEEE Transactions on Computational Imaging, 2018. 


pre-print: http://users.ics.forth.gr/~greg/publications.html
