function [RES]=evaluate_on_IMEC55_multis(num_band,sz,smp_scenario,num_obs_pxl,GRMR_params)
%% change it to my camera in hand
ubuntu_flag = 1;
if ubuntu_flag ==1
    testimg_dir = '/data1/user1/dataset/25bands/static_zoom/test/';
    save_dir = '/data1/user1/results/New_IMEC_55/real/';
    save_dir1 = '/data1/user1/results/New_IMEC_55/real/real_buff/';
else
    testimg_dir = 'F:\data\25bands\600_875\';
    save_dir = 'F:\OneDriveSchool\OneDrive - mail.nwpu.edu.cn\results\New_IMEC_55\non_deep\';
end

% img_list = {'dadongmenguangchang_filter1_0'};
files = dir([testimg_dir,'*.tif']);
size0 = size(files);
length_img = size0(1);
for i=1:length_img    
    % testimg_name = 'beads_ms';
%     testimg_name = img_list{m};
    testimg_name = strrep(files(i,1).name,'.tif','');
    [testimg_name]
    if exist([save_dir,testimg_name,'_I_PPID_repair','.tif'],'file')~=0 || exist([save_dir1,testimg_name,'_I_PPID_repair','.tif'],'file')~=0
        disp([save_dir,testimg_name,'_I_PPID_repair','.tif',' has exist']);
        continue;
    end
%     patch_start=[1,201];     %start position of test image patch 
    patch_start=[1,1];
    [I_HS,I1_SMP_SEQ]=load_snapshot_w_band_new(sz,patch_start,num_band,[testimg_dir,testimg_name,'.tif']);  
    [I_MOS_seq]=simulate_video(I_HS,I1_SMP_SEQ,num_obs_pxl,num_band);
    sz = size(I_HS);

    if num_band==25
        load('mine_response_55.mat');
        SpectralProfiles = 1000*mine_response_55;
        CentralWavelengths = [604.009252,612.562958,870.862811,871.287603,675.8564,798.197455,810.679616,...
            786.703654,773.498085,683.152094,748.690923,762.086195,736.472977,722.40953,697.766181,642.550291,...
            651.044318,634.558225,625.488686,667.942182,851.323732,862.925954,841.356284,829.968991,659.063553,];
    elseif num_band==16
    %     load('spectral_responses_4x4.mat');
        load('mine_response.mat')
        SpectralProfiles = 1000*mine_response;
        CentralWavelengths = [481.06, 489.87, 480.51,636.59,591.76,602.14,578.5,567.2,633.67,488.56,624.48,615.83,529.46,543.01,515.78,504.65];
    else
        disp('Error');
    end
    %615.8292651264626,624.4814994467588,633.674023812103
    temp2=sort( round(CentralWavelengths))-400;
    SpectralProfiles=SpectralProfiles(:,temp2);
    SpectralProfiles=rot90(SpectralProfiles);
    CentralWavelengths_sorted = sort(CentralWavelengths);

    mx=max(max(max(I_HS)));
    I_HS=I_HS./mx;
    I_HS=I_HS*255;
    I_HS=round(I_HS);

    [n1,n2,n3]=size(I_HS);

    [SMP_seq,FilterPattern_lst]=make_sampling_operators(n1,n2,n3,num_obs_pxl,num_band,smp_scenario,SpectralProfiles);

    SMP_SEQ=SMP_seq;

    I_WB_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);
    I_BTES_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);
    I_ItSD_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);
    I_PPID_repair_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);

    for pp=1:num_obs_pxl
        I_MOS=I_MOS_seq(:,:,pp);
        FilterPattern=cell2mat(FilterPattern_lst(pp));

        disp('Running WB');
        I_WB_tmp(:,:,:,pp)=run_WB(I_MOS,FilterPattern,num_band);
%         disp('Running PPID');
%         PPI=mean(squeeze(I_WB_tmp(:,:,:,pp)),3);
%         I_PPID_tmp(:,:,:,pp)=run_PPID(I_MOS,FilterPattern,num_band,PPI);
        disp('Running PPID_repair');
        PPI_1 = computeIntensity_multi(I_MOS,num_band);
        I_PPID_repair_tmp(:,:,:,pp)=run_PPID(I_MOS,FilterPattern,num_band,PPI_1);
%         disp('Running BTES');
%         I_BTES_tmp(:,:,:,pp)=run_BTES(I_MOS,FilterPattern,num_band,squeeze(I_WB_tmp(:,:,:,pp)));
        disp('Running ItSD');
        I_ItSD_tmp(:,:,:,pp)=ItSD_Mine(I_MOS,FilterPattern,num_band,CentralWavelengths_sorted);
    end

    I_WB=mean(I_WB_tmp,4);
    I_BTES=mean(I_BTES_tmp,4);
    I_ItSD=mean(I_ItSD_tmp,4);
    I_PPID_repair=mean(I_PPID_repair_tmp,4);


%     imwrite(uint8(I_HS),[save_dir,testimg_name,'_I_HS','.tif']);
    imwriteTiff(I_PPID_repair,[save_dir,testimg_name,'_I_PPID_repair','.tif']);
    imwriteTiff(I_ItSD,[save_dir,testimg_name,'_I_ItSD','.tif']);
    imwriteTiff(I_WB,[save_dir,testimg_name,'_I_WB','.tif']);
end
RES={I_HS,I_GRMR_rec,I_BTES,I_WB,I_PPID,I_ItSD};




