function [SMP_seq,FilterPattern_lst]=make_sampling_operators(n1,n2,n3,num_obs_pxl,num_band,smp_scenario,SpectralProfiles)

for tt=1:num_band
    
    tmp=(rand(1,num_band));
    tmp=tmp/sum(tmp);
    rand_pattern(tt,:)=tmp;
end


for ww=1:num_obs_pxl
    ptn1=randperm(num_band);
    if num_band == 16
        ptn1(1) = 2;
        ptn1(2) = 4;
        ptn1(3) = 1;
        ptn1(4) = 16;
        ptn1(5) = 11;
        ptn1(6) = 12;
        ptn1(7) = 10;
        ptn1(8) = 9;
        ptn1(9) = 15;
        ptn1(10) = 3;
        ptn1(11) = 14;
        ptn1(12) = 13;
        ptn1(13) = 7;
        ptn1(14) = 8;
        ptn1(15) = 6;
        ptn1(16) = 5;
    elseif num_band ==25
        ptn1 = 1:1:num_band;
    end
    
    ptn2=reshape(ptn1,[sqrt(num_band),sqrt(num_band)]);
    ptn2 = ptn2';
    r1=n1/sqrt(num_band);
    r2=n2/sqrt(num_band);
    FilterPattern=repmat(ptn2,[r1,r2]);
    FilterPattern_lst{ww}=FilterPattern;
end



SMP_seq=zeros(n1,n2,num_band,num_obs_pxl);

for xx=1:n1
    for yy=1:n2
        for qq=1:num_obs_pxl
            FilterPattern=FilterPattern_lst{qq};
            selected_band=FilterPattern(xx,yy);
            
%             tmp=zeros(1,n3);
            tmp=zeros(1,num_band);
            switch smp_scenario
                case 1
                    tmp(selected_band)=1;
                case 2
                    tmp=rand_pattern(selected_band,:);
                case 3
                    selected_profile=SpectralProfiles(selected_band,:);
                    selected_profile=selected_profile./sum(selected_profile);
                    tmp=selected_profile;
            end
            
            SMP_seq(xx,yy,:,qq)=tmp;
        end
    end
end

