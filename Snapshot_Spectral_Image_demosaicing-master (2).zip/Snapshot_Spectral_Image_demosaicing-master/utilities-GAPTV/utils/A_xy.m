function  y = A_xy(z, Phi)
   
y = sum(Phi.*z, 3);
end