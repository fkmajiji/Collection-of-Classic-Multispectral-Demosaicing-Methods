function [im_input1]=raw_multispectral_S_N1(im_label,scale)
% this function return the Synthetic raw multispectral image which has been
% repeated l_1 times
[hei,wid,l] = size(im_label);
%im_input = zeros(hei,wid,l,'double');
im_input1 = zeros(hei,wid,'double');
%im_input1 = zeros(hei,wid,n,'single');
k=1;
l_1=scale*scale;
assert(l_1==l, 'Number of band should be same with the square of scale');
for bandc=1:scale
   for bandr=1:scale   
        k = (bandc-1)*scale + bandr ;
        im_input1(bandc:scale:hei,bandr:scale:wid)=im_label(bandc:scale:hei,bandr:scale:wid,k);        
   end
end
%im_input = repmat(im_input1,[1,1,16,1]);