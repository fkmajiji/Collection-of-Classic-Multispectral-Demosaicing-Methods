function I_NLbian=run_bianTIP(meas,FilterPattern,num_band,orig)

[n1,n2]=size(meas);

m=zeros(n1,n2,num_band);
mask=zeros(n1,n2,num_band);
for xx=1:n1
    for yy=1:n2
        tmp1=meas(xx,yy);
        tmp2=FilterPattern(xx,yy);
        m(xx,yy,tmp2)=tmp1;
        mask(xx,yy,tmp2)=1;
    end
end

%------------- Start Parallel ----------
delete(gcp('nocreate')); % delete current parpool
mycluster = parcluster('local');
div = 1;
while num_band/div > mycluster.NumWorkers
  div = div+1;
end
parnum = max(min(ceil(num_band/div),mycluster.NumWorkers),1); 
parpool(mycluster,parnum+1);

%% [2.3] GAP-TV reconstruction
% mask is 0-1 binary mask(m*n*c); meas is mosaic image; m is splitted
% sparse multi-band cube
[vgaptv,psnr_gaptv,ssim_gaptv,tgaptv]  = func_GAPTV(mask,meas,orig);
disp('GAP-TV')
psnr_gaptv,ssim_gaptv,tgaptv
%% [2.4] Ours reconstruction
[I_NLbian,psnr_ours,ssim_ours,tours] = func_Ours(mask,m,orig,255.*vgaptv);
disp('Ours')
psnr_ours,ssim_ours,tours
                  
delete(gcp('nocreate')); % delete current parpool

