function numIteration=ComputeNIteration(num_band, CentralWavelengths_sorted)
for k = 1: num_band
  for l = 1:num_band
    if k ~= l
      lambdaL = CentralWavelengths_sorted(l);
      lambdaK = CentralWavelengths_sorted(k);
      numIteration(l,k) = round(exp(-(abs(lambdaK - lambdaL) - 100.0)/34.8) + 1.0);
    end
  end
end
end
