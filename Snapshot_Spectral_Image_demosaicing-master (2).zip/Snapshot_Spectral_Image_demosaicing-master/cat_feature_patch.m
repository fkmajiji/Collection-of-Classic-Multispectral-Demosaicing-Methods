testimg_dir = 'F:\CODE\';
save_patch = 'F:\�����޸�\IEEE-Transactions-LaTeX2e-templates-and-instructions\IEEETransactions_LaTeX\IEEEtran\figures\';
% F:\CODE\Raw_Conv_mosaic_attention_ZX_MA\feautures\att1
files = dir(testimg_dir);
size0 = size(files);
length_img = size0(1);
attention_name = 'att1';
feature_order = '7';
% img_name = {'room_scene_colorchecker_testborad_prefix_6'};
% img_name = {'small_5_0_0'};
method_list = {'Raw_Conv_mosaic_attention_ZX_MA','Raw_Conv_mosaic_attention_SE'};
for j = 1 : length(method_list)
    fileName = strcat(testimg_dir,method_list{j},'\feautures\',attention_name,'\',feature_order,'.png'); 
    [fileName]
    if j==1
        I_HS = (imread(fileName));
        I1= I_HS(:,:,1:3);
        [I11,rect]=imcrop(I1);
        rect_buff = floor(rect/4);
        rect_buff1 = rect_buff*4;
        rect = rect_buff1
        I33 = I_HS(rect(2)+1:rect(2)+rect(4),rect(1)+1:rect(1)+rect(3),:);
%             imwriteTiff(I33,[testimg_dir,img_name{i},'_',method_list{j},'_patch','.tif']);
        imwrite(I33,[save_patch,method_list{j},'_',attention_name,'_',feature_order,'_fea_patch','.png']);
    else
        I_HS = (imread(fileName));

        I33 = I_HS(rect(2)+1:rect(2)+rect(4),rect(1)+1:rect(1)+rect(3),:);
%             imwriteTiff(I33,[testimg_dir,img_name{i},'_',method_list{j},'_patch','.tif']);
        imwrite(I33,[save_patch,method_list{j},'_',attention_name,'_',feature_order,'_fea_patch','.png']);
    end

end

