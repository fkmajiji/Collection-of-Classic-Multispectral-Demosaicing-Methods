function [mean_PSNR,mean_SAM, exec_time,std_PSNSR,std_SAM]=evaluate_on_CAVE_paper_TT31_GRMR(num_band,sz,smp_scenario,num_obs_pxl,GRMR_params)
%% only for GRMR on TT31
% for zz=1:numel(fnames)-2
%     fname=fnames(zz+2).name;    
%     fprintf('%s, %d out of %d\n',fname,zz,numel(fnames)-2);
%     I_HS=load_hypercube_CAVE(fname,sz,num_band);
testimg_dir = 'G:\dataset\TT31_mine\';
files = dir(testimg_dir);
size0 = size(files);
length_img = size0(1);
% illum_name = {'D65','DE','F12','HA'};
illum_name = {'D65'};
img_name = {'Butterfly','Butterfly2','Butterfly3','Butterfly4','Butterfly5','Butterfly6','Butterfly7','Butterfly8','CD','Character','Cloth','Cloth2','Cloth3','Cloth4','Cloth5','Cloth6','Color','Colorchart','Doll','Fan','Fan2','Fan3','Flower','Flower2','Flower3','Party','Tape','Tape2','Tshirts','Tshirts2'};
% img_name = {'Colorchart'};
for i = 1 : length(img_name)
    for j = 1 : length(illum_name)
        fileName = strcat(testimg_dir,img_name{i},'IMECMine_',illum_name{j},'.tif'); 
    %                     im_old = imreadTiff([fileName,'\',illus{illu},'.tif']);
        [fileName]
        I_HS = double(imreadTiff(fileName));
%         I_HS = double(imreadTiff([fileName,'\','IMEC',illum_name{j},'.tif']));   
        I_HS = I_HS(1:sz(1),1:sz(2),:);
        mx=max(max(max(I_HS)));
        I_HS=I_HS./mx;
        I_HS=I_HS*255;
        I_HS=round(I_HS);
        I_HS = reorder_imec(I_HS);
        if num_band==25
    %         load('spectral_responses_5x5.mat');
            load('mine_response_55.mat')
            SpectralProfiles = 1000*mine_response_55;
            CentralWavelengths = [891.228063968467,900.4136806241354,882.6390340688997,872.8273953098562,959.1581529553714,798.1721280626637,810.6644104934758,786.6630469829357,773.4684267556538,683.125314825705,748.6209746262925,762.0732717672614,736.4469322775088,722.4361633246994,697.7817125343055,931.7518268181563,939.0137082184392,923.6129587168447,915.0633215022599,953.0919464020343,851.3598834968631,862.9590913973506,841.3304918423851,829.9358579773984,946.0467183645011];
        elseif num_band==16
    %         load('spectral_responses_4x4.mat');
    %         CentralWavelengths=CentralWavelength;
            load('mine_response.mat')
            SpectralProfiles = 1000*mine_response;
            CentralWavelengths = [481.06, 489.87, 480.51,636.59,591.76,602.14,578.5,567.2,633.67,488.56,624.48,615.83,529.46,543.01,515.78,504.65];
        else
            disp('Error');
        end
        CentralWavelengths_sorted = sort(CentralWavelengths);
        temp2=sort( round(CentralWavelengths))-400;
        SpectralProfiles=SpectralProfiles(:,temp2);
        SpectralProfiles=rot90(SpectralProfiles);

        [n1,n2,n3]=size(I_HS);


        [SMP_seq,FilterPattern_lst]=make_sampling_operators2_mine(n1,n2,n3,num_obs_pxl,num_band,smp_scenario,SpectralProfiles);
        [I_MOS_seq]=acquire_observations(I_HS,SMP_seq,num_obs_pxl);

        SMP_SEQ=SMP_seq;

        I_WB_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);
        I_BTES_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);
        I_ItSD_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);
        I_PPID_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);

        disp('Running WB');
        tic;
        for pp=1:num_obs_pxl
            I_MOS=I_MOS_seq(:,:,pp);
            FilterPattern=cell2mat(FilterPattern_lst(pp));
            I_WB_tmp(:,:,:,pp)=run_WB(I_MOS,FilterPattern,num_band);
        end
        I_WB=mean(I_WB_tmp,4);
        WB_toc=toc;

        offset=GRMR_params.offset;
        maxIter=GRMR_params.maxIter;
        sgm2=GRMR_params.sgm2;
        gamma=GRMR_params.gamma;
        rank_sel=GRMR_params.rank_sel;
        disp('Running GRMR');
        tic;
        I_GRMR_rec=run_GRMR_demosaick(I_MOS_seq,SMP_SEQ,num_band,offset,sgm2,maxIter,rank_sel,gamma,I_WB);
        GRMR_toc=toc;


        disp('Running PPID');
        tic
%         for pp=1:num_obs_pxl
%             I_MOS=I_MOS_seq(:,:,pp);
%             FilterPattern=cell2mat(FilterPattern_lst(pp));
%             PPI=mean(squeeze(I_WB_tmp(:,:,:,pp)),3);
%             PPI_1 = computeIntensity_multi(I_MOS,num_band);
%             I_PPID_tmp(:,:,:,pp)=run_PPID(I_MOS,FilterPattern,num_band,PPI_1);
%         end
%         I_PPID=mean(I_PPID_tmp,4);
        I_PPID = I_WB;
        PPID_toc=toc;

        disp('Running wrong BTES equals WB');
        tic;
%         for pp=1:num_obs_pxl
%             I_MOS=I_MOS_seq(:,:,pp);
%             FilterPattern=cell2mat(FilterPattern_lst(pp));
%             I_BTES_tmp(:,:,:,pp)=run_BTES(I_MOS,FilterPattern,num_band,squeeze(I_WB_tmp(:,:,:,pp)));
%         end
%         I_BTES=mean(I_BTES_tmp,4);
        I_BTES = I_WB;
        BTES_toc=toc;

        disp('Running ItSD');
        tic;
%         for pp=1:num_obs_pxl
%             I_MOS=I_MOS_seq(:,:,pp);
%             FilterPattern=cell2mat(FilterPattern_lst(pp));
% %             I_ItSD_tmp(:,:,:,pp)=run_ItSD(I_MOS,FilterPattern,num_band);
%             I_ItSD_tmp(:,:,:,pp) = ItSD_Mine(I_MOS,FilterPattern,num_band,CentralWavelengths_sorted);
%         end
%         I_ItSD=mean(I_ItSD_tmp,4);
        I_ItSD = I_WB;
        ItSD_toc=toc;
        
%         for band=1:num_band
%             err_ItSD(band)=psnr(squeeze(I_ItSD(:,:,band)),squeeze(I_HS(:,:,band)),256);
%         end
%         mean_PSNR=[mean(mean(err_ItSD))];
%         mean_PSNR

        for band=1:num_band
            err_GRMR(band)=psnr(squeeze(I_GRMR_rec(:,:,band)),squeeze(I_HS(:,:,band)),256);
            err_PPID(band)=psnr(squeeze(I_PPID(:,:,band)),squeeze(I_HS(:,:,band)),256);
            err_WB(band)=psnr(squeeze(I_WB(:,:,band)),squeeze(I_HS(:,:,band)),256);
            err_ItSD(band)=psnr(squeeze(I_ItSD(:,:,band)),squeeze(I_HS(:,:,band)),256);
            err_BTES(band)=psnr(squeeze(I_BTES(:,:,band)),squeeze(I_HS(:,:,band)),256);
        end
        mean_PSNR=[mean(mean(err_GRMR)),mean(mean(err_BTES)),mean(mean(err_WB)),mean(mean(err_PPID)),mean(mean(err_ItSD))];
        mean_PSNR
        imwriteTiff(I_GRMR_rec,['Result_TT31/',img_name{i},'IMECMine_',illum_name{j},'_I_GRMR_rec','.tif']);
%         imwriteTiff(I_PPID,['Result_TT31/',files(i,1).name,'_',illum_name{j},'_I_PPID','.tif']);
%         imwriteTiff(I_ItSD,['Result_TT31/',files(i,1).name,'_',illum_name{j},'_I_ItSD','.tif']);
%         imwriteTiff(I_WB,['Result_TT31/',files(i,1).name,'_',illum_name{j},'_I_WB','.tif']);
%         imwriteTiff(I_BTES,['Result_TT31/',files(i,1).name,'_',illum_name{j},'_I_BTES','.tif']);
    end
end

exec_time=[GRMR_toc,BTES_toc,WB_toc,PPID_toc,ItSD_toc];
mean_PSNR=[mean(mean(err_GRMR)),mean(mean(err_BTES)),mean(mean(err_WB)),mean(mean(err_PPID)),mean(mean(err_ItSD))];
mean_SAM=[mean((err_SAM_GRMR)),mean((err_SAM_BTES)),mean((err_SAM_WB)),mean((err_SAM_PPID)),mean((err_SAM_ItSD))];
std_PSNSR=[std(mean(err_GRMR)),std(mean(err_BTES)),std(mean(err_WB)),std(mean(err_PPID)),std(mean(err_ItSD))];
std_SAM=[std((err_SAM_GRMR)),std((err_SAM_BTES)),std((err_SAM_WB)),std((err_SAM_PPID)),std((err_SAM_ItSD))];
