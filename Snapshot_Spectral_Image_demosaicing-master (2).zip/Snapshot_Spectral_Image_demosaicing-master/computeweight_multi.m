function W = computeweight_multi(x, y, dx, dy, msfa, pt_size)
W = 0;
W1 = 0;
epsilon = 1;
if ((dx == 0)||(dy == 0))
    for i=0:1
%         W = W + 2*(2 - i)* abs(msfa(x + dx * (4 - i), y + dy * (4 - i)) ...
%             - msfa(x - dx * i, y - dy * i));
%         W = W + (2 - i)*abs(msfa(x + dx * (4 - i) + dy, y + dy * (4 - i) + dx)...
%             - msfa(x - dx * i + dy, y - dy * i + dx));
%         W = W + (2 - i)*abs(msfa(x + dx * (4 - i) - dy, y + dy * (4 - i) - dx)...
%             - msfa(x - dx * i - dy, y - dy * i - dx)); 
        W1 = W1 + 2 * (2 - i) * abs(msfa(x + dx * (pt_size + i), y + dy * (pt_size + i)) - msfa(x + dx * i, y + dy * i));
        W1 = W1 + (2 - i) * abs(msfa(x + dx * (pt_size + i) + dy, y + dy * (pt_size + i) + dx) - msfa(x + dx * i + dy, y + dy * i + dx));
        W1 = W1 + (2 - i) * abs(msfa(x + dx * (pt_size + i) - dy, y + dy * (pt_size + i) - dx) - msfa(x + dx * i - dy, y + dy * i - dx));
        buff = 0;
    end
    W = 1/(epsilon + W1);
else
    for i=0:1
%         x + dx * (4 - i), y + dy * (4 - i)
%         x - dx * i, y - dy * i

%         x + dx * (4 - i), y + dy * (4 - i) - dy
%         x - dx * i , y - dy * i - dy
      
%         x + dx * (4 - i) - dx, y + dy * (4 - i)
%         x - dx * i - dx, y - dy * i
%         W = W + 2*(2 - i)* abs(msfa(x + dx * (4 - i), y + dy * (4 - i)) ...
%             - msfa(x - dx * i, y - dy * i));
%         W = W + (2 - i)*abs(msfa(x + dx * (4 - i), y + dy * (4 - i) - dy)...
%             - msfa(x - dx * i , y - dy * i - dy));
%         W = W + (2 - i)*abs(msfa(x + dx * (4 - i) - dx, y + dy * (4 - i) )...
%             - msfa(x - dx * i - dx, y - dy * i ));     
%         x + dx * (4 + i), y + dy * (4 + i)
%         x + dx * i, y + dy * i
        
%         x + dx * (4 + i), y + dy * (4 + i) + dy
%         x + dx * i, y + dy * i + dy
        
%         x + dx * (4 + i) + dx, y + dy * (4 + i)
%         x + dx * i + dx, y + dy * i
        
        W1 = W1 + 2 * (2 - i) * abs(msfa(x + dx * (pt_size + i), y + dy * (pt_size + i)) - msfa(x + dx * i, y + dy * i));
        W1 = W1 + (2 - i) * abs(msfa(x + dx * (pt_size + i), y + dy * (pt_size + i) + dy) - msfa(x + dx * i, y + dy * i + dy));
        W1 = W1 + (2 - i) * abs(msfa(x + dx * (pt_size + i) + dx, y + dy * (pt_size + i)) - msfa(x + dx * i + dx, y + dy * i)); 
        buff = 0;
    end
    W = 1/(epsilon + W1);
end

end
