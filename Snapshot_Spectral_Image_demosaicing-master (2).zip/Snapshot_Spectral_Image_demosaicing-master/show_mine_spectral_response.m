load('mine_response_55.mat')
for i=15:16
    plot(mine_response_55(i,:));
    hold on;
end
% for i=10:10
%     plot(mine_response_55(i,:));
%     hold on;
% end