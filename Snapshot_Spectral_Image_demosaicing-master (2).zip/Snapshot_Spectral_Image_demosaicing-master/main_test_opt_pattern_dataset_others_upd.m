clear 
close all
%% method perform good except the GRMR
smp_scenario=3; %sampling operator, 1=binary, 2=random projections, 3=filter based
num_obs_pxl=1;  %number of exposures

GRMR_params.offset=5;
GRMR_params.maxIter=10; %was 20
GRMR_params.sgm2=1e1;
GRMR_params.gamma=0.2;
GRMR_params.rank_sel=2;

dataset = 'ICVL25'; % can be NTIRE16 or ICVL25 or IMEC25
if contains(dataset, 'ICVL25')
    num_band = 25;
    msfa_size = 5;
    testimg_dir = '/data1/fengkai/dataset/ICVL/IMEC25_600/test/';
    ext = '.tif';
    save_dir = '/data1/fengkai/results/IMEC55_ICVL/';
elseif contains(dataset, 'NTIRE16')
    num_band=16;    %number of bands
    msfa_size = 5;
    testimg_dir = '/data2/fengkai/dataset/NRITE/valid_spectral_16/';
    ext = '.mat';
    save_dir = '/data1/user1/results/NTIRE44/';
elseif contains(dataset, 'IMEC25')
    num_band = 25;
    msfa_size = 5;
    ext = '.tif';
    testimg_dir = '/data1/user1/dataset/25bands/600_875/';
    save_dir = '/data1/user1/results/New_IMEC_55/non_deep/';
end
files = dir([testimg_dir,'*',ext]);
size0 = size(files);
length_img = size0(1);
t_WB=0;
t_PPID=0;
t_ItSD=0;
t_NL=0;
t_BTES=0;

patch_test_mode = 1;
EN_WB = 0;
EN_PPID = 0;
EN_ItSD = 0;
EN_NL = 1;
EN_BTES = 0;

buff_name_lists = {'gavyam_0823-0944_IMECMine55_Orillum'};
length_img = length(buff_name_lists);
for i=1:length_img  
    testimg_name = strrep(files(i,1).name, ext,'');
    testimg_name = buff_name_lists{i};
%     testimg_name = '2020_5_29_day_sunlight_filter1_5';

    [testimg_name]
    if exist([save_dir,testimg_name,'_I_PPID','.tif'],'file')~=0
        disp([save_dir,testimg_name,'_I_PPID','.tif',' has exist']);
%             continue;
    end
    fileName = strcat(testimg_dir,testimg_name,ext); 
    if contains(ext,'tif')
        im_old = double(imreadTiff(fileName));
    elseif contains(ext,'mat')
        load(fileName);
        im_old = cube;
    end
%         im_old = im_old(1:1000,1:1000,:);
    sz = size(im_old);
    sz(1) = floor(sz(1)/sqrt(num_band))*sqrt(num_band);
    sz(2) = floor(sz(2)/sqrt(num_band))*sqrt(num_band);
    im_old = im_old(1:sz(1),1:sz(2),:);
    if ~contains(dataset, 'IMEC25')
        im_label = double(im_old(:,:,:));
        mx=max(im_label(:));
        im_label=im_label./mx;
        im_label=im_label*255;
        im_label=round(im_label);
    else
        im_label = repmat(im_old, 1, 1, num_band);    
    end
    ori_sz = size(im_label);
    if patch_test_mode
        sz(1) = 250;
        sz(2) = 250;        
        if strcmp(testimg_name, 'grf_0328-0949_IMECMine55_Orillum')
            % grf_0328-0949_IMECMine55_Orillum_GT_repatch_547_724_55_55
            rect = [547,724,55,55];
        elseif strcmp(testimg_name, 'Labtest_0910-1510_IMECMine55_Orillum')
            % Labtest_0910-1510_IMECMine55_Orillum_I_ItSD_patch_319_763_43_40
            rect = [319,763,43,40];
        elseif strcmp(testimg_name, 'gavyam_0823-0944_IMECMine55_Orillum')
            % gavyam_0823-0944_IMECMine55_Orillum_DIP00_patch_799_669_56_53
            rect = [799,669,56,53];          
        elseif strcmp(testimg_name, '2020_5_29_day_sunlight_filter1_5')
            % 2020_5_29_day_sunlight_filter1_5_DIP00_patch_1304_117_65_63
            rect = [1304,117,65,63];
        elseif strcmp(testimg_name, 'DADONGMENG1_unprocessed_VIDEO_biascor')
            % DADONGMENG1_unprocessed_VIDEO_biascor_patch_122_405_130_128
            rect = [122,405,130,128];
        elseif strcmp(testimg_name, 'Real_Wusi_Real_Wusi_biascor')
            % Real_Wusi_Real_Wusi_biascor_DIP00_patch_535_356_158_151
            rect = [535,356,158,151];
        elseif strcmp(testimg_name, 'newxiao_unprocessed_newxiao3_biascor')
            % newxiao_unprocessed_newxiao3_biascor_DIP00_patch_465_303_47_45
            rect = [465,303,47,45];
        elseif strcmp(testimg_name, 'newxiao_unprocessed_newxiao2_biascor')
            % newxiao_unprocessed_newxiao2_biascor_DIP00_patch_373_775_75_71
            rect = [373,775,75,71];
        elseif strcmp(testimg_name, 'new2xiao_unprocessed_new2xiao1_biascor')
            % new2xiao_unprocessed_new2xiao1_biascor_DIP00_patch_1843_573_47_46
            rect = [1843,573,47,46];
        elseif strcmp(testimg_name, 'dadongmenguangchang_filter1_0')
            % dadongmenguangchang_filter1_0_DIP00_patch_1336_640_69_65
            rect = [1336,640,69,65];
        elseif strcmp(testimg_name, 'fullpip_unprocessed_full2_biascor')
            % fullpip_unprocessed_full2_biascor_DIP00_patch_1118_384_65_60
            rect = [1118,384,65,60];
        elseif strcmp(testimg_name, 'DADONGMENG_unprocessed_4_biascor')
            % DADONGMENG_unprocessed_4_biascor_DIP00_patch_529_700_33_31
            rect = [529,700,33,31];
        elseif strcmp(testimg_name, 'DADONGMENG_unprocessed_2_biascor')
            % DADONGMENG_unprocessed_2_biascor_DIP00_patch_755_579_54_51
            % DADONGMENG_unprocessed_2_biascor_DIP00_patch_331_401_25_24
            rect = [331,401,25,24];
        end
        
        pt_start1 = rect(2) - (sz(1) - rect(4))/2;
        pt_start1 = floor(pt_start1/msfa_size)*msfa_size + 1;
        pt_start2 = rect(1) - (sz(1) - rect(3))/2;
        pt_start2 = floor(pt_start2/msfa_size)*msfa_size + 1;

        if pt_start1 < 0
            pt_start1 = 1;
        end
        if pt_start2 < 0
            pt_start2 = 1;
        end
    else
        pt_start1 = 1;
        pt_start2 = 1;
    end

    im_label = im_label(pt_start1:pt_start1-1+sz(1),pt_start2:pt_start2-1+sz(2),:);
    
    [I_HS,I1_SMP_SEQ]=load_snapshot_w_band_mycave(sz,num_band,im_label);
    [I_MOS_seq]=simulate_video(I_HS,I1_SMP_SEQ,num_obs_pxl,num_band);


    if num_band==25
%         load('spectral_responses_5x5.mat');
        %�˴�����5_5�����xml�ļ������Ϣ
        load('mine_response_55.mat')
        SpectralProfiles = 1000*mine_response_55;
        CentralWavelengths = [891.228063968467,900.4136806241354,882.6390340688997,872.8273953098562,959.1581529553714,798.1721280626637,810.6644104934758,786.6630469829357,773.4684267556538,683.125314825705,748.6209746262925,762.0732717672614,736.4469322775088,722.4361633246994,697.7817125343055,931.7518268181563,939.0137082184392,923.6129587168447,915.0633215022599,953.0919464020343,851.3598834968631,862.9590913973506,841.3304918423851,829.9358579773984,946.0467183645011];
    elseif num_band==16
    %     load('spectral_responses_4x4.mat');
        load('mine_response.mat')
        SpectralProfiles = 1000*mine_response;
    %     CentralWavelengths=CentralWavelength;
    %     CentralWavelengths = [481.9026, 492.7445, 507.4158, 519.8557, 533.1545, 545.0216, 569.0783, 581.3583, 593.5562, 604.8488, 617.3455, 626.5296, 634.0547];
    %    CentralWavelengths = [482.0300, 492.6200, 478.7100, 478.7200, 593.5600, 605.0900, 581.6000, 569.0800, 633.8100, 490.2500, 626.9000, 617.3500, 533.1500, 545.0200, 519.8600, 507.2900];
        CentralWavelengths = [481.06, 489.87, 480.51,636.59,591.76,602.14,578.5,567.2,633.67,488.56,624.48,615.83,529.46,543.01,515.78,504.65];
    else
        disp('Error');
    end
    %615.8292651264626,624.4814994467588,633.674023812103
    temp2=sort( round(CentralWavelengths))-400;
    SpectralProfiles=SpectralProfiles(:,temp2);
    SpectralProfiles=rot90(SpectralProfiles);
    CentralWavelengths_sorted = sort(CentralWavelengths);

%     mx=max(max(max(I_HS)));
%     I_HS=I_HS./mx;
%     I_HS=I_HS*255;
%     I_HS=round(I_HS);

    [n1,n2,n3]=size(I_HS);

    [SMP_seq,FilterPattern_lst]=make_sampling_operators_noreorder(n1,n2,n3,num_obs_pxl,num_band,smp_scenario,SpectralProfiles);

    SMP_SEQ=SMP_seq;

    I_WB_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);
    I_BTES_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);
    I_ItSD_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);
    I_PPID_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);
    I_NL_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);

    for pp=1:num_obs_pxl
        I_MOS=I_MOS_seq(:,:,pp);
        FilterPattern=cell2mat(FilterPattern_lst(pp));

        if EN_WB
            disp('Running WB');
            tic
            I_WB_tmp(:,:,:,pp)=run_WB(I_MOS,FilterPattern,num_band);
            toc
            t_WB=t_WB+toc;
        end
        
        if EN_PPID
            disp('Running PPID');
            tic
            PPI_1 = computeIntensity_multi(I_MOS,num_band);
            I_PPID_tmp(:,:,:,pp)=run_PPID(I_MOS,FilterPattern,num_band,PPI_1);
            toc
            t_PPID=t_PPID+toc;
        end
        
        if EN_BTES
            disp('Running BTES');
            tic
            I_BTES_tmp(:,:,:,pp)=run_BTES(I_MOS,FilterPattern,num_band,squeeze(I_WB_tmp(:,:,:,pp)));
            toc
            t_BTES=t_BTES+toc;
        end
        
        if EN_ItSD
            disp('Running ItSD');
            tic
            I_ItSD_tmp(:,:,:,pp)=ItSD_Mine(I_MOS,FilterPattern,num_band,CentralWavelengths_sorted);
            toc
            t_ItSD=t_ItSD+toc;
        end
        
        if EN_NL
            disp('Running NL-bianTIP');
            tic
            I_NL_tmp(:,:,:,pp)=run_bianTIP(I_MOS,FilterPattern,num_band,im_label);
            toc
            t_NL = t_NL + toc;
        end
    end

    I_WB=mean(I_WB_tmp,4);
    I_BTES=mean(I_BTES_tmp,4);
    I_ItSD=mean(I_ItSD_tmp,4);
    I_PPID=mean(I_PPID_tmp,4);
    I_NL=mean(I_NL_tmp,4);

    offset=GRMR_params.offset;
    maxIter=GRMR_params.maxIter; 
    sgm2=GRMR_params.sgm2; 
    gamma=GRMR_params.gamma; 
    rank_sel=GRMR_params.rank_sel;


    disp('Running GRMR');
%         I_GRMR_rec=run_GRMR_demosaick(I_MOS_seq,SMP_SEQ,num_band,offset,sgm2,maxIter,rank_sel,gamma,I_WB);
    I_GRMR_rec = I_BTES;
    for band=1:num_band
        err_GRMR(band)=psnr(squeeze(I_GRMR_rec(:,:,band)),squeeze(im_label(:,:,band)),256);
        err_PPID(band)=psnr(squeeze(I_PPID(:,:,band)),squeeze(im_label(:,:,band)),256);
        err_WB(band)=psnr(squeeze(I_WB(:,:,band)),squeeze(im_label(:,:,band)),256);
        err_ItSD(band)=psnr(squeeze(I_ItSD(:,:,band)),squeeze(im_label(:,:,band)),256);
        err_BTES(band)=psnr(squeeze(I_BTES(:,:,band)),squeeze(im_label(:,:,band)),256);
        err_NL(band)=psnr(squeeze(I_NL(:,:,band)),squeeze(im_label(:,:,band)),256);
    end
    mean_PSNR=[mean(mean(err_GRMR)),mean(mean(err_BTES)),mean(mean(err_WB)),mean(mean(err_PPID)),mean(mean(err_ItSD)),mean(mean(err_NL))];
    mean_PSNR

%         imwrite(uint8(I_HS),['Result_CAVE_MINE1/',files(i,1).name,'_',illum_name{j},'_I_HS','_TT31','.tif']);
    if EN_PPID
        save_mat = zeros(ori_sz);
        save_mat(pt_start1:pt_start1-1+sz(1),pt_start2:pt_start2-1+sz(2),:) = I_PPID;
        imwriteTiff(save_mat,[save_dir,testimg_name,'_I_PPID','.tif']);
    end
    
    if EN_ItSD
        save_mat = zeros(ori_sz);
        save_mat(pt_start1:pt_start1-1+sz(1),pt_start2:pt_start2-1+sz(2),:) = I_ItSD;
        imwriteTiff(save_mat,[save_dir,testimg_name,'_I_ItSD','.tif']);
    end
    
    if EN_WB
        save_mat = zeros(ori_sz);
        save_mat(pt_start1:pt_start1-1+sz(1),pt_start2:pt_start2-1+sz(2),:) = I_WB;
        imwriteTiff(save_mat,[save_dir,testimg_name,'_I_WB','.tif']);
    end
    
    if EN_NL
        save_mat = zeros(ori_sz);
        save_mat(pt_start1:pt_start1-1+sz(1),pt_start2:pt_start2-1+sz(2),:) = I_NL;
        imwriteTiff(save_mat,[save_dir,testimg_name,'_I_NL','.tif']);
    end
end

fprintf('the average time of WB   is %.4f\n',t_WB/length_img);
fprintf('the average time of PPID is %.4f\n',t_PPID/length_img);
fprintf('the average time of ItSD is %.4f\n',t_ItSD/length_img);
fprintf('the average time of BTES is %.4f\n',t_BTES/length_img);
fprintf('the average time of NL is %.4f\n',t_NL/length_img);
RES={I_HS,I_GRMR_rec,I_BTES,I_WB,I_PPID,I_ItSD,I_NL};




