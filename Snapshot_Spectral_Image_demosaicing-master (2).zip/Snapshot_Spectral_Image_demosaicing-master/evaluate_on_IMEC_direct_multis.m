% multi-images
num_band=16;    %number of bands
sz=[1000,1600];     %image size for 6/9
smp_scenario=1; %sampling operator, 1=binary, 2=random projections, 3=filter based
num_obs_pxl=1;  %number of exposures

GRMR_params.offset=5;
GRMR_params.maxIter=20; %was 20
GRMR_params.sgm2=1e1;
GRMR_params.gamma=0.2;
GRMR_params.rank_sel=2;
%% change it to my camera in hand
testimg_dir = '/data1/user1/dataset/test_real_mine/';
out_dir = '/data1/user1/results/Result_IMEC_realscene/';
% img_list = {'4_LED26W_2','4_LED26W_1','4_LED26W_0','4_LED26W_9','room_scene_colorchecker_testborad_prefix_9'};
img_list = {'room_scene_colorchecker_testborad_prefix_6','mei_shanghai_5_0','outside_palace_small_easterngate2_prefix_13','outside_palace_big_easterngate_prefix_4'};
img_paper_list = {'4_LED26W_2', 'room_scene_colorchecker_testborad_prefix_6','mei_shanghai_5_0','outside_palace_small_easterngate2_prefix_13','outside_palace_big_easterngate_prefix_4'};
for m=1:length(img_list)    
    % testimg_name = 'beads_ms';
    testimg_name = img_list{m}
    patch_start=[1,201];     %start position of test image patch 
    % patch_start=[1,1];
    % [I_HS,I1_SMP_SEQ]=load_snapshot_w_band_new(sz,num_band,[testimg_dir,testimg_name,'\',testimg_name,'\','IMECMine_D65.tif']);
    [I_HS,I1_SMP_SEQ]=load_snapshot_w_band_new(sz,patch_start,num_band,[testimg_dir,testimg_name,'.tif']);
    [I_MOS_seq]=simulate_video(I_HS,I1_SMP_SEQ,num_obs_pxl,num_band);


    if num_band==25
        load('spectral_responses_5x5.mat');
    elseif num_band==16
    %     load('spectral_responses_4x4.mat');
        load('mine_response.mat')
        SpectralProfiles = 1000*mine_response;
    %     CentralWavelengths=CentralWavelength;
    %     CentralWavelengths = [481.9026, 492.7445, 507.4158, 519.8557, 533.1545, 545.0216, 569.0783, 581.3583, 593.5562, 604.8488, 617.3455, 626.5296, 634.0547];
    %    CentralWavelengths = [482.0300, 492.6200, 478.7100, 478.7200, 593.5600, 605.0900, 581.6000, 569.0800, 633.8100, 490.2500, 626.9000, 617.3500, 533.1500, 545.0200, 519.8600, 507.2900];
        CentralWavelengths = [481.06, 489.87, 480.51,636.59,591.76,602.14,578.5,567.2,633.67,488.56,624.48,615.83,529.46,543.01,515.78,504.65];
    else
        disp('Error');
    end
    %615.8292651264626,624.4814994467588,633.674023812103
    temp2=sort( round(CentralWavelengths))-400;
    SpectralProfiles=SpectralProfiles(:,temp2);
    SpectralProfiles=rot90(SpectralProfiles);
    CentralWavelengths_sorted = sort(CentralWavelengths);

    mx=max(max(max(I_HS)));
    I_HS=I_HS./mx;
    I_HS=I_HS*255;
    I_HS=round(I_HS);

    [n1,n2,n3]=size(I_HS);

    [SMP_seq,FilterPattern_lst]=make_sampling_operators(n1,n2,n3,num_obs_pxl,num_band,smp_scenario,SpectralProfiles);

    SMP_SEQ=SMP_seq;

    I_WB_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);
    I_BTES_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);
    I_ItSD_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);
    I_PPID_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);
    I_PPID_repair_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);

    for pp=1:num_obs_pxl
        I_MOS=I_MOS_seq(:,:,pp);
        FilterPattern=cell2mat(FilterPattern_lst(pp));

        disp('Running WB');
        I_WB_tmp(:,:,:,pp)=run_WB(I_MOS,FilterPattern,num_band);
%         disp('Running PPID');
%         PPI=mean(squeeze(I_WB_tmp(:,:,:,pp)),3);
%         I_PPID_tmp(:,:,:,pp)=run_PPID(I_MOS,FilterPattern,num_band,PPI);
%         disp('Running PPID_repair');
%         PPI_1 = computeIntensity_multi(I_MOS,num_band);
%         I_PPID_repair_tmp(:,:,:,pp)=run_PPID(I_MOS,FilterPattern,num_band,PPI_1);
%         disp('Running BTES');
%         I_BTES_tmp(:,:,:,pp)=run_BTES(I_MOS,FilterPattern,num_band,squeeze(I_WB_tmp(:,:,:,pp)));
%         disp('Running ItSD');
%         I_ItSD_tmp(:,:,:,pp)=ItSD_Mine(I_MOS,FilterPattern,num_band,CentralWavelengths_sorted);
        I_BTES_tmp = I_WB_tmp;
        I_ItSD_tmp = I_WB_tmp;
        I_PPID_tmp = I_WB_tmp;
        I_PPID_repair_tmp = I_WB_tmp;
    end

    I_WB=mean(I_WB_tmp,4);
    I_BTES=mean(I_BTES_tmp,4);
    I_ItSD=mean(I_ItSD_tmp,4);
    I_PPID=mean(I_PPID_tmp,4);
    I_PPID_repair=mean(I_PPID_repair_tmp,4);

    offset=GRMR_params.offset;
    maxIter=GRMR_params.maxIter; 
    sgm2=GRMR_params.sgm2; 
    gamma=GRMR_params.gamma; 
    rank_sel=GRMR_params.rank_sel;


    disp('Running GRMR');
    I_GRMR_rec=run_GRMR_demosaick(I_MOS_seq,SMP_SEQ,num_band,offset,sgm2,maxIter,rank_sel,gamma,I_WB);

%     imwrite(uint8(I_HS),['Result_IMEC_realscene/',testimg_name,'_I_HS','.tif']);
    imwriteTiff(I_GRMR_rec,[out_dir,testimg_name,'_I_GRMR_rep','.tif']);
%     imwriteTiff(I_PPID,['Result_IMEC_realscene/',testimg_name,'_I_PPID','.tif']);
%     imwriteTiff(I_PPID_repair,['Result_IMEC_realscene/',testimg_name,'_I_PPID_repair','.tif']);
%     imwriteTiff(I_ItSD,['Result_IMEC_realscene/',testimg_name,'_I_ItSD','.tif']);
    imwriteTiff(I_WB,[out_dir,testimg_name,'_I_WB_1','.tif']);
%     imwriteTiff(I_BTES,['Result_IMEC_realscene/',testimg_name,'_I_BTES','.tif']);
end


