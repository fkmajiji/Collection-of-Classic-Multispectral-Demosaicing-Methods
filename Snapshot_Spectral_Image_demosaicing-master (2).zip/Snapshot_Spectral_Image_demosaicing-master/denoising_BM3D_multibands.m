function clear_image = denoising_BM3D_multibands(dirty_image, sigma)
%input and output are all uint8
[~,~,bn] = size(dirty_image);
for zn =1:bn
    z = dirty_image(:,:,zn);
%     avg_input = mean(mean(z));
%     figure; imshow(z);  title(sprintf('origin:%d,max:%d',zn,avg_input))
%     sprintf('%s,max:%d','�������ֵ',avg_input);
    [~, y_est] = BM3D(1, z, sigma); 
%     mean_res = mean(mean(y_est));
%     sprintf('sigma:%d,max:%d',sigma,mean_res);
    clear_image(:,:,zn) = y_est* 255.0;
%     figure; imshow(y_est);title(sprintf('sigma:%d,max:%d',sigma,mean_res));
end


% Standard deviation of the noise --- corresponding to intensity 
%  range [0,255], despite that the input was scaled in [0,1]
% sigma = 15;
% Add the AWGN with zero mean and standard deviation 'sigma'
% z = y + (sigma/255)*randn(size(y));
% Denoise 'z'. The denoised image is 'y_est', and 'NA = 1' because 
%  the true image was not provided
% [NA, y_est] = BM3D(1, z, sigma); 
% Compute the putput PSNR
% PSNR = 10*log10(1/mean((y(:)-y_est(:)).^2))
% show the noisy image 'z' and the denoised 'y_est'
 
% figure; imshow(y_est);