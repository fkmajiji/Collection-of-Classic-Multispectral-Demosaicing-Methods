function [RES]=evaluate_on_IMEC55_multis_NL_bian(num_band,sz,smp_scenario,num_obs_pxl,GRMR_params)
%% change it to my camera in hand
ubuntu_flag = 1;
if ubuntu_flag ==1
%     testimg_dir = '/data1/user1/dataset/25bands/static_zoom/test/';
    testimg_dir = '/data1/user1/dataset/25bands/600_875/';
    save_dir = '/data1/user1/results/New_IMEC_55/real/';
    save_dir1 = '/data1/user1/results/New_IMEC_55/real/real_buff/';
else
    testimg_dir = 'F:\data\25bands\600_875\';
    save_dir = 'F:\OneDriveSchool\OneDrive - mail.nwpu.edu.cn\results\New_IMEC_55\non_deep\';
end

% img_list = {'dadongmenguangchang_filter1_0'};
files = dir([testimg_dir,'*.tif']);
size0 = size(files);
length_img = size0(1);
img_list = {'2020_5_29_day_sunlight_filter1_5','DADONGMENG_unprocessed_5_biascor','DADONGMENG_unprocessed_2_biascor'};
for i=1:length(img_list)        
    testimg_name = img_list{i};
%     testimg_name = strrep(files(i,1).name,'.tif','');
    [testimg_name]
    if exist([save_dir,testimg_name,'_I_NL','.tif'],'file')~=0 || exist([save_dir1,testimg_name,'_I_PPID_repair','.tif'],'file')~=0
        disp([save_dir,testimg_name,'_I_NL','.tif',' has exist']);
        continue;
    end
    patch_start=[1,1];
    [I_HS,I1_SMP_SEQ]=load_snapshot_w_band_new(sz,patch_start,num_band,[testimg_dir,testimg_name,'.tif']);
    [I_MOS_seq]=simulate_video(I_HS,I1_SMP_SEQ,num_obs_pxl,num_band);
    sz(1) = 150;
    sz(2) = 150;
    if strcmp(testimg_name, 'newxiao_unprocessed_newxiao2_biascor')
        I_HS = I_HS(601:600+sz(1),901:900+sz(2),:);
        I_MOS_seq = I_HS;
    elseif strcmp(testimg_name, 'refpip_unprocessed_refpip2_biascor')
        I_HS = I_HS(541:540+sz(1),201:200+sz(2),:);
        I_MOS_seq = I_HS;
    elseif strcmp(testimg_name, 'DADONGMENG_unprocessed_6_biascor')
        I_HS = I_HS(801:800+sz(1),1001:1000+sz(2),:);
        I_MOS_seq = I_HS;
    elseif strcmp(testimg_name, '2020_5_29_day_sunlight_filter1_5')
        %         _I_ItSD_patch_1348_746_37_37
        I_HS = I_HS(701:700+sz(1),1301:1300+sz(2),:);
        I_MOS_seq = I_HS;
    elseif strcmp(testimg_name, 'DADONGMENG_unprocessed_5_biascor')
        %         _I_ItSD_patch_685_179_45_44
        I_HS = I_HS(101:100+sz(1),601:600+sz(2),:);
        I_MOS_seq = I_HS;
    elseif strcmp(testimg_name, 'DADONGMENG_unprocessed_2_biascor')
        %         _I_PPID_repair_patch_331_401_25_24
        I_HS = I_HS(351:350+sz(1),301:300+sz(2),:);
        I_MOS_seq = I_HS;
    end


    if num_band==25
        load('mine_response_55.mat');
        SpectralProfiles = 1000*mine_response_55;
        CentralWavelengths = [604.009252,612.562958,870.862811,871.287603,675.8564,798.197455,810.679616,...
            786.703654,773.498085,683.152094,748.690923,762.086195,736.472977,722.40953,697.766181,642.550291,...
            651.044318,634.558225,625.488686,667.942182,851.323732,862.925954,841.356284,829.968991,659.063553,];
    elseif num_band==16
    %     load('spectral_responses_4x4.mat');
        load('mine_response.mat')
        SpectralProfiles = 1000*mine_response;
        CentralWavelengths = [481.06, 489.87, 480.51,636.59,591.76,602.14,578.5,567.2,633.67,488.56,624.48,615.83,529.46,543.01,515.78,504.65];
    else
        disp('Error');
    end
    %615.8292651264626,624.4814994467588,633.674023812103
    temp2=sort( round(CentralWavelengths))-400;
    SpectralProfiles=SpectralProfiles(:,temp2);
    SpectralProfiles=rot90(SpectralProfiles);
    CentralWavelengths_sorted = sort(CentralWavelengths);

    [n1,n2,n3]=size(I_HS);

    [SMP_seq,FilterPattern_lst]=make_sampling_operators(n1,n2,n3,num_obs_pxl,num_band,smp_scenario,SpectralProfiles);

    SMP_SEQ=SMP_seq;

    I_WB_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);
    I_NL_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);

    for pp=1:num_obs_pxl
        I_MOS=I_MOS_seq(:,:,pp);
        FilterPattern=cell2mat(FilterPattern_lst(pp));

        disp('Running WB');
        I_WB_tmp(:,:,:,pp)=run_WB(I_MOS,FilterPattern,num_band);
        disp('Running NL-bianTIP');
        I_NL_tmp(:,:,:,pp)=run_bianTIP(I_MOS,FilterPattern,num_band,I_WB_tmp(:,:,:,pp));
    end

    I_WB=mean(I_WB_tmp,4);
    I_NL=mean(I_NL_tmp,4);
   
%     imwrite(uint8(I_HS),[save_dir,testimg_name,'_I_HS','.tif']);
%     imwriteTiff(I_GRMR_rec,[save_dir,testimg_name,'_I_GRMR_rec','.tif']);
%     imwriteTiff(I_PPID,[save_dir,testimg_name,'_I_PPID','.tif']);
%     imwriteTiff(I_PPID_repair,[save_dir,testimg_name,'_I_PPID_repair','.tif']);
%     imwriteTiff(I_WB,[save_dir,testimg_name,'_I_WB_buff','.tif']);
    imwriteTiff(I_NL,[save_dir,testimg_name,'_I_NL','.tif']);
%     imwriteTiff(I_BTES,[save_dir,testimg_name,'_I_BTES','.tif']);
end
RES={I_HS,I_GRMR_rec,I_BTES,I_WB,I_PPID,I_ItSD};




