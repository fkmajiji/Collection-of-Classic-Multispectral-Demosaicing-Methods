function [I1_MOS,I1_SMP_SEQ,band_sorted]=load_snapshot_w_band_new(sz,patch_start,num_band, testimg_name)

if num_band==25
    load spectral_responses_5x5
%     I1_MOS=double(imread('example1_5x5.pgm'));
    I1_MOS = double(imread(testimg_name));
    CentralWavelengths=round(CentralWavelengths);
elseif num_band==16
%     load spectral_responses_4x4
%     Wavelength = round(CentralWavelength);
%     I1_MOS=double(imread('example1_4x4.pgm'));
%     I1_MOS=double(imread('example2_4x4.pgm'));
    load('mine_response.mat')
    SpectralProfiles = 1000*mine_response;
    I1_MOS = double(imread(testimg_name));
    CentralWavelength = [481.06, 489.87, 480.51,636.59,591.76,602.14,578.5,567.2,633.67,488.56,624.48,615.83,529.46,543.01,515.78,504.65];
    CentralWavelengths=round(CentralWavelength);
end

band_sel=round(CentralWavelengths-400);

S=SpectralProfiles(:,band_sel);

[~,band_sorted]=sort(CentralWavelengths);


for tt=1:num_band
    S(tt,:)=S(tt,:)/sum(S(tt,:));
end

sz = size(I1_MOS);
S2=reshape(S,[sqrt(num_band),sqrt(num_band),num_band]);
I1_SMP_SEQ=repmat(S2,[sz(1)/sqrt(num_band),sz(2)/sqrt(num_band),1]);


I1_MOS=I1_MOS(patch_start(1):patch_start(1)+sz(1)-1,patch_start(2):patch_start(2)+sz(2)-1);
% I1_MOS=(I1_MOS./max(max(I1_MOS)))*255;

return
