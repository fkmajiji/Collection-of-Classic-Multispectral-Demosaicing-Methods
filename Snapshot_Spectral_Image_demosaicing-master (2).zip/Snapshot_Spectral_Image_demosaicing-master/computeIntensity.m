function Intensity = computeIntensity(msfa)
FilterM = [0.015625, 0.03125, 0.03125, 0.03125, 0.015625; ...
           0.03125,  0.0625,  0.0625,  0.0625,  0.03125; ...
           0.03125,  0.0625,  0.0625,  0.0625,  0.03125; ...
           0.03125,  0.0625,  0.0625,  0.0625,  0.03125; ...
           0.015625, 0.03125, 0.03125, 0.03125, 0.015625];
Intensity = conv2(msfa, FilterM, 'same');
fp = Intensity;
[hei,wid] = size(msfa);
% for x = 5:(wid-4)
%     for y = 5:(hei-4)
for x = 7:(wid-6)
    for y = 7:(hei-6) 
        %����
        Wse = computeweight(x, y, 1, -1, msfa);
        Wnw = computeweight(x, y, -1, 1, msfa);
        Wne = computeweight(x, y, 1, 1, msfa);       
        Wsw = computeweight(x, y, -1, -1, msfa);
        Ws = computeweight(x, y, 0, -1, msfa);
        Wn = computeweight(x, y, 0, 1, msfa); 
        We = computeweight(x, y, 1, 0, msfa);
        Ww = computeweight(x, y, -1, 0, msfa);
        average = (((-msfa(x + 4, y) + fp(x + 4, y)) * We + (-msfa(x - 4, y) + fp(x - 4, y)) * Ww + (-msfa(x, y + 4) + fp(x, y + 4)) * Wn + (-msfa(x, y - 4)+ fp(x, y - 4))...
            * Ws + (-msfa(x - 4, y - 4) + fp(x - 4, y - 4)) * Wsw + (-msfa(x + 4, y - 4) + fp(x + 4, y - 4)) * Wse + ...
            (-msfa(x - 4, y + 4) + fp(x - 4, y + 4)) * Wnw + (-msfa(x + 4, y + 4) + fp(x + 4, y + 4)) * Wne) / (Ww + We + Ws + Wn + Wnw + Wse + Wsw + Wne));
        average1 = (((-msfa(x + 4, y) + fp(x + 4, y)) * We + (-msfa(x - 4, y) + fp(x - 4, y)) * Ww + (-msfa(x, y + 4) + fp(x, y + 4)) * Wn + (-msfa(x, y - 4) + fp(x, y - 4))...
            * Ws + (-msfa(x - 4, y - 4) + fp(x - 4, y - 4)) * Wsw + (-msfa(x + 4, y - 4) + fp(x + 4, y - 4)) * Wse + ...
            (-msfa(x - 4, y + 4) + fp(x - 4, y + 4)) * Wnw + (-msfa(x + 4, y + 4) + fp(x + 4, y + 4)) * Wne) / (Ww + We + Ws + Wn + Wnw + Wse + Wsw + Wne));        
        pixelValue = (msfa(x, y) + average);
        if pixelValue < 0
            pixelValue = 0; 
        end
        Intensity(x, y) = pixelValue;
    end
end  
end