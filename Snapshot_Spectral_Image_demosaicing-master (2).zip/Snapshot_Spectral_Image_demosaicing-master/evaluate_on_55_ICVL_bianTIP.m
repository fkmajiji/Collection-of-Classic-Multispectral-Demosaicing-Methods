%% method perform good except the GRMR
num_band=25;    %number of bands
smp_scenario=3; %sampling operator, 1=binary, 2=random projections, 3=filter based
num_obs_pxl=1;
testimg_dir = '/data1/user1/dataset/ICVL/IMEC25_600/test/buff/';
save_dir = '/data1/user1/results/IMEC55_ICVL/';
illum_name = {'Orillum'}; 
files = dir([testimg_dir,'*.tif']);
size0 = size(files);
length_img = size0(1);
for i=1:length_img  
    for j = 1 : length(illum_name)
        
        testimg_name = strrep(files(i,1).name,'.tif','');
%         testimg_name = 'omer_0331-1130_IMECMine55_Orillum';
        [testimg_name]
        if exist([save_dir,testimg_name,'_I_NL','.tif'],'file')~=0
            disp([save_dir,testimg_name,'_I_NL','.tif',' has exist']);
%             continue;
        end
        fileName = strcat(testimg_dir,testimg_name,'.tif'); 
        im_old = double(imreadTiff(fileName));
        sz = size(im_old);
        sz(1) = floor(sz(1)/sqrt(num_band))*sqrt(num_band);
        sz(2) = floor(sz(2)/sqrt(num_band))*sqrt(num_band);
        im_old = im_old(1:sz(1),1:sz(2),:);        
        im_label = double(im_old(:,:,:));
        mx=max(max(max(im_label)));
        im_label=im_label./mx;
        sz(1) = 250;
        sz(2) = 250;
        if strcmp(testimg_name, 'nachal_0823-1110_IMECMine55_Orillum')
            im_label = im_label(200:199+sz(1),300:299+sz(2),:);
        elseif strcmp(testimg_name, 'grf_0328-0949_IMECMine55_Orillum')
            % grf_0328-0949_IMECMine55_Orillum_GT_repatch_547_724_55_55
            im_label = im_label(650:649+sz(1),450:449+sz(2),:);
        elseif strcmp(testimg_name, 'omer_0331-1130_IMECMine55_Orillum')
            im_label = im_label(300:299+sz(1),650:649+sz(2),:);
        elseif strcmp(testimg_name, 'bulb_0822-0909_IMECMine55_Orillum')
            % bulb_0822-0909_IMECMine55_Orillum_ICVL_LSA_5_EItrain_Transrandomnew_220921_1958355700_patch_567_863_27_27
            im_label = im_label(700:699+sz(1),400:399+sz(2),:);
        elseif strcmp(testimg_name, 'eve_0331-1632_IMECMine55_Orillum')
            % eve_0331-1632_IMECMine55_Orillum_ICVL_LSA_5_EItrain_Transrandomnew_220921_1958355700_patch_707_394_37_36
            im_label = im_label(300:299+sz(1),600:599+sz(2),:);
        end
        im_label=im_label*255;
        im_label=round(im_label);
        [I_HS,I1_SMP_SEQ]=load_snapshot_w_band_mycave(sz,num_band,im_label);
        [I_MOS_seq]=simulate_video(I_HS,I1_SMP_SEQ,num_obs_pxl,num_band);


        if num_band==25
    %         load('spectral_responses_5x5.mat');
            %�˴�����5_5�����xml�ļ������Ϣ
            load('mine_response_55.mat')
            SpectralProfiles = 1000*mine_response_55;
            CentralWavelengths = [891.228063968467,900.4136806241354,882.6390340688997,872.8273953098562,959.1581529553714,798.1721280626637,810.6644104934758,786.6630469829357,773.4684267556538,683.125314825705,748.6209746262925,762.0732717672614,736.4469322775088,722.4361633246994,697.7817125343055,931.7518268181563,939.0137082184392,923.6129587168447,915.0633215022599,953.0919464020343,851.3598834968631,862.9590913973506,841.3304918423851,829.9358579773984,946.0467183645011];
        elseif num_band==16
        %     load('spectral_responses_4x4.mat');
            load('mine_response.mat')
            SpectralProfiles = 1000*mine_response;
        %     CentralWavelengths=CentralWavelength;
        %     CentralWavelengths = [481.9026, 492.7445, 507.4158, 519.8557, 533.1545, 545.0216, 569.0783, 581.3583, 593.5562, 604.8488, 617.3455, 626.5296, 634.0547];
        %    CentralWavelengths = [482.0300, 492.6200, 478.7100, 478.7200, 593.5600, 605.0900, 581.6000, 569.0800, 633.8100, 490.2500, 626.9000, 617.3500, 533.1500, 545.0200, 519.8600, 507.2900];
            CentralWavelengths = [481.06, 489.87, 480.51,636.59,591.76,602.14,578.5,567.2,633.67,488.56,624.48,615.83,529.46,543.01,515.78,504.65];
        else
            disp('Error');
        end
        %615.8292651264626,624.4814994467588,633.674023812103
        temp2=sort( round(CentralWavelengths))-400;
        SpectralProfiles=SpectralProfiles(:,temp2);
        SpectralProfiles=rot90(SpectralProfiles);
        CentralWavelengths_sorted = sort(CentralWavelengths);

    %     mx=max(max(max(I_HS)));
    %     I_HS=I_HS./mx;
    %     I_HS=I_HS*255;
    %     I_HS=round(I_HS);

        [n1,n2,n3]=size(I_HS);

        [SMP_seq,FilterPattern_lst]=make_sampling_operators(n1,n2,n3,num_obs_pxl,num_band,smp_scenario,SpectralProfiles);

        SMP_SEQ=SMP_seq;

        I_WB_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);
        I_NL_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);
        
        for pp=1:num_obs_pxl
            I_MOS=I_MOS_seq(:,:,pp);
            FilterPattern=cell2mat(FilterPattern_lst(pp));
            disp('Running WB');
            I_WB_tmp(:,:,:,pp)=run_WB(I_MOS,FilterPattern,num_band);
            disp('Running NL-bianTIP');
            I_NL_tmp(:,:,:,pp)=run_bianTIP(I_MOS,FilterPattern,num_band,im_label);
        end

        I_WB=mean(I_WB_tmp,4);
        I_NL=mean(I_NL_tmp,4);

        for band=1:num_band
            err_WB(band)=psnr(squeeze(I_WB(:,:,band)),squeeze(im_label(:,:,band)),256);
            err_NL(band)=psnr(squeeze(I_NL(:,:,band)),squeeze(im_label(:,:,band)),256);
            
        end
        mean_PSNR=[mean(mean(err_WB)),mean(mean(err_NL))];
        mean_PSNR
        imwriteTiff(I_NL,[save_dir,testimg_name,'_I_NL','.tif']);
    end
end
RES={I_HS,I_GRMR_rec,I_BTES,I_WB,I_PPID,I_ItSD};




