function [RES]=evaluate_on_CAVE_Mine(num_band,sz,smp_scenario,num_obs_pxl,GRMR_params)

testimg_dir = 'G:\dataset\CAVE2\validation_CAVE\';
files = dir(testimg_dir);
size0 = size(files);
length_img = size0(1);
illum_name = {'D65','DE','F12','HA'};
for i = 3 : length_img
    for j = 1 : 4
        fileName = strcat(testimg_dir,files(i,1).name,'\',files(i,1).name); 
    %                     im_old = imreadTiff([fileName,'\',illus{illu},'.tif']);
        [fileName,'\','IMECMine_',illum_name{j},'.tif']
        im_old = imreadTiff([fileName,'\','IMECMine_',illum_name{j},'.tif']);
        im_old = im_old(1:sz(1),1:sz(2),:);
        im_label = double(im_old(:,:,:));
        mx=max(max(max(im_label)));
        im_label=im_label./mx;
        im_label=im_label*255;
        im_label=round(im_label);
        [I_HS,I1_SMP_SEQ]=load_snapshot_w_band_mycave(sz,num_band,im_label);
        im_label = reorder_imec(im_label);
        [I_MOS_seq]=simulate_video(I_HS,I1_SMP_SEQ,num_obs_pxl,num_band);


        if num_band==25
    %         load('spectral_responses_5x5.mat');
            %�˴�����5_5�����xml�ļ������Ϣ
            load('mine_response_5_5.mat')
            SpectralProfiles = 1000*mine_response;
            CentralWavelengths = [891.228063968467,900.4136806241354,882.6390340688997,872.8273953098562,959.1581529553714,798.1721280626637,810.6644104934758,786.6630469829357,773.4684267556538,683.125314825705,748.6209746262925,762.0732717672614,736.4469322775088,722.4361633246994,697.7817125343055,931.7518268181563,939.0137082184392,923.6129587168447,915.0633215022599,953.0919464020343,851.3598834968631,862.9590913973506,841.3304918423851,829.9358579773984,946.0467183645011];
        elseif num_band==16
        %     load('spectral_responses_4x4.mat');
            load('mine_response.mat')
            SpectralProfiles = 1000*mine_response;
        %     CentralWavelengths=CentralWavelength;
        %     CentralWavelengths = [481.9026, 492.7445, 507.4158, 519.8557, 533.1545, 545.0216, 569.0783, 581.3583, 593.5562, 604.8488, 617.3455, 626.5296, 634.0547];
        %    CentralWavelengths = [482.0300, 492.6200, 478.7100, 478.7200, 593.5600, 605.0900, 581.6000, 569.0800, 633.8100, 490.2500, 626.9000, 617.3500, 533.1500, 545.0200, 519.8600, 507.2900];
            CentralWavelengths = [481.06, 489.87, 480.51,636.59,591.76,602.14,578.5,567.2,633.67,488.56,624.48,615.83,529.46,543.01,515.78,504.65];
        else
            disp('Error');
        end
        %615.8292651264626,624.4814994467588,633.674023812103
        temp2=sort( round(CentralWavelengths))-400;
        SpectralProfiles=SpectralProfiles(:,temp2);
        SpectralProfiles=rot90(SpectralProfiles);
        CentralWavelengths_sorted = sort(CentralWavelengths);

    %     mx=max(max(max(I_HS)));
    %     I_HS=I_HS./mx;
    %     I_HS=I_HS*255;
    %     I_HS=round(I_HS);

        [n1,n2,n3]=size(I_HS);

        [SMP_seq,FilterPattern_lst]=make_sampling_operators(n1,n2,n3,num_obs_pxl,num_band,smp_scenario,SpectralProfiles);

        SMP_SEQ=SMP_seq;

        I_WB_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);
        I_BTES_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);
        I_ItSD_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);
        I_PPID_tmp=zeros(sz(1),sz(2),num_band,num_obs_pxl);


        for pp=1:num_obs_pxl
            I_MOS=I_MOS_seq(:,:,pp);
            FilterPattern=cell2mat(FilterPattern_lst(pp));

%             disp('Running WB');
%             I_WB_tmp(:,:,:,pp)=run_WB(I_MOS,FilterPattern,num_band);
%             disp('Running PPID');
%             PPI=mean(squeeze(I_WB_tmp(:,:,:,pp)),3);
%             PPI_1 = computeIntensity_multi(I_MOS,num_band);
%             I_PPID_tmp(:,:,:,pp)=run_PPID(I_MOS,FilterPattern,num_band,PPI_1);
%             disp('Running BTES');
%             I_BTES_tmp(:,:,:,pp)=run_BTES(I_MOS,FilterPattern,num_band,squeeze(I_WB_tmp(:,:,:,pp)));
            disp('Running ItSD');
            I_ItSD_tmp(:,:,:,pp)=ItSD_Mine(I_MOS,FilterPattern,num_band,CentralWavelengths_sorted);
            I_WB_tmp = I_ItSD_tmp;
            I_BTES_tmp =I_ItSD_tmp;
            I_PPID_tmp = I_ItSD_tmp;

        end

        I_WB=mean(I_WB_tmp,4);
        I_BTES=mean(I_BTES_tmp,4);
        I_ItSD=mean(I_ItSD_tmp,4);
        I_PPID=mean(I_PPID_tmp,4);


        offset=GRMR_params.offset;
        maxIter=GRMR_params.maxIter; 
        sgm2=GRMR_params.sgm2; 
        gamma=GRMR_params.gamma; 
        rank_sel=GRMR_params.rank_sel;


        disp('Running GRMR');
%         I_GRMR_rec=run_GRMR_demosaick(I_MOS_seq,SMP_SEQ,num_band,offset,sgm2,maxIter,rank_sel,gamma,I_WB);
        I_GRMR_rec = I_ItSD;
        for band=1:num_band
            err_GRMR(band)=psnr(squeeze(I_GRMR_rec(:,:,band)),squeeze(im_label(:,:,band)),256);
            err_PPID(band)=psnr(squeeze(I_PPID(:,:,band)),squeeze(im_label(:,:,band)),256);
            err_WB(band)=psnr(squeeze(I_WB(:,:,band)),squeeze(im_label(:,:,band)),256);
            err_ItSD(band)=psnr(squeeze(I_ItSD(:,:,band)),squeeze(im_label(:,:,band)),256);
            err_BTES(band)=psnr(squeeze(I_BTES(:,:,band)),squeeze(im_label(:,:,band)),256);
        end
        mean_PSNR=[mean(mean(err_GRMR)),mean(mean(err_BTES)),mean(mean(err_WB)),mean(mean(err_PPID)),mean(mean(err_ItSD))];
        mean_PSNR
%         imwrite(uint8(I_HS),['Result_CAVE_MINE1/',files(i,1).name,'_',illum_name{j},'_I_HS','.tif']);
%         imwriteTiff(I_GRMR_rec,['Result_CAVE_MINE1/',files(i,1).name,'_',illum_name{j},'_I_GRMR_rec','.tif']);
%         imwriteTiff(I_PPID,['Result_CAVE_MINE1/',files(i,1).name,'_',illum_name{j},'_I_PPID','.tif']);
        imwriteTiff(I_ItSD,['Result_CAVE_MINE1/',files(i,1).name,'_',illum_name{j},'_I_ItSD','.tif']);
%         imwriteTiff(I_WB,['Result_CAVE_MINE1/',files(i,1).name,'_',illum_name{j},'_I_WB','.tif']);
%         imwriteTiff(I_BTES,['Result_CAVE_MINE1/',files(i,1).name,'_',illum_name{j},'_I_BTES','.tif']);
    end
end
RES={I_HS,I_GRMR_rec,I_BTES,I_WB,I_PPID,I_ItSD};




